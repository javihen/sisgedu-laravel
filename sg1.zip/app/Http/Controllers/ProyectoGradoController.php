<?php

namespace App\Http\Controllers;

use App\Models\Curso;
use App\Models\Estudiante;
use App\Models\Gestion;
use App\Models\Profesor;
use App\Models\ProyectoEstudiante;
use App\Models\ProyectoGrado;
use App\Models\ProyectoSeguimiento;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProyectoGradoController extends Controller
{
    public function index()
    {
        $proyectos = ProyectoGrado::with([
            'estudiante',
            'tutor',
            'curso',
            'gestion',
            'tribunales.profesor',
            'defensa',
            'proyectoEstudiantes.estudiante',
            'dictamenOficial',
        ])->orderBy('titulo', 'asc')
            ->paginate(6);

        $gestionActual = session('gestion_activa');
        $estudiantesDisponibles = DB::table('inscripciones as i')
            ->join('estudiantes as e', 'e.id_estudiante', '=', 'i.id_estudiante')
            ->where('e.estado', 'E')
            ->join('cursos as c', 'c.id', '=', 'i.id_curso')
            ->where('c.grado', 6)
            ->where('c.nivel', 2)
            ->where('i.id_gestion', $gestionActual)
            ->whereNotExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('proyecto_estudiantes as pe')
                    ->whereColumn('pe.id_estudiante', 'i.id_estudiante');
            })
            ->orderBy('e.nombres', 'asc')
            ->get();

        return view(
            'proyectoGrado.index',
            compact('proyectos', 'estudiantesDisponibles')
        );
    }

    public function seguimiento(string $idProyecto)
    {
        $proyecto = ProyectoGrado::with([
            'estudiante',
            'proyectoEstudiantes.estudiante',
            'tutor',
            'curso',
            'gestion',
            'tribunales.profesor',
            'defensa',
            'seguimientos',
        ])->findOrFail($idProyecto);

        return view(
            'proyectoGrado.seguimiento',
            compact('proyecto')
        );
    }

    public function guardarDictamen(Request $request, string $idProyecto)
    {
        $proyecto = ProyectoGrado::findOrFail($idProyecto);
        abort_unless(
            session('profesor_id') !== null
                && (string) session('profesor_id') === (string) $proyecto->idProfesorTutor,
            403,
            'Solo el tutor designado puede registrar el dictamen del proyecto.'
        );

        $validated = $request->validate([
            'dictamen_estado' => ['required', 'in:sin_visto_bueno,en_lectura,informe_favorable,habilitado_defensa'],
            'fecha_dictamen' => ['required', 'date'],
            'tipo_resolucion' => ['required', 'in:unanimidad,mayoria,menores,reestructuracion'],
            'observaciones' => ['nullable', 'string', 'max:5000'],
            'declaracion_jurada' => ['accepted'],
        ]);

        $estados = [
            'sin_visto_bueno' => 'Sin visto bueno',
            'en_lectura' => 'En lectura metodológica',
            'informe_favorable' => 'Informe favorable',
            'habilitado_defensa' => 'Habilitado para la defensa',
        ];
        $resoluciones = [
            'unanimidad' => 'Aprobado por Unanimidad (2/2)',
            'mayoria' => 'Aprobado por Mayoría con Respaldo Técnico',
            'menores' => 'Con Observaciones Menores no Impeditivas',
            'reestructuracion' => 'Rechazado para Reestructuración Profunda',
        ];

        DB::transaction(function () use ($proyecto, $validated, $estados, $resoluciones) {
            ProyectoGrado::whereKey($proyecto->getKey())->lockForUpdate()->firstOrFail();

            $dictamen = ProyectoSeguimiento::where('idProyecto', $proyecto->idProyecto)
                ->where('titulo', 'like', 'Dictamen oficial:%')
                ->lockForUpdate()
                ->orderByDesc('idSeguimiento')
                ->first();

            if ($dictamen && str_starts_with($dictamen->titulo, 'Dictamen oficial: Habilitado para la defensa')) {
                abort(403, 'El dictamen no se puede modificar después de habilitar la defensa.');
            }

            $attributes = [
                'fecha' => $validated['fecha_dictamen'],
                'titulo' => 'Dictamen oficial: ' . $estados[$validated['dictamen_estado']],
                'descripcion' => $resoluciones[$validated['tipo_resolucion']],
                'observacion' => $validated['observaciones'] ?? null,
            ];

            if ($dictamen) {
                $dictamen->update($attributes);
            } else {
                $proyecto->seguimientos()->create($attributes);
            }
        });

        return redirect()
            ->route('proyectoGrado.index')
            ->with('success', 'Dictamen oficial guardado correctamente.');
    }

    public function searchXCurso(string $id)
    {
        $proyectos = ProyectoGrado::with([
            'estudiante',
            'tutor',
            'curso',
            'gestion',
            'tribunales.profesor',
            'defensa',
            'proyectoEstudiantes.estudiante',
            'dictamenOficial',
        ])->where('idCurso', $id)
            ->orderBy('titulo', 'asc')
            ->get();

        $estudiantesDisponibles = Estudiante::where('estado', 'E')
            ->whereDoesntHave('proyectoGrado')
            ->whereDoesntHave('proyectoEstudiantes')
            ->whereHas('inscripciones', function ($query) use ($id) {
                $query->where('id_curso', $id);
            })
            ->orderBy('nombres', 'asc')
            ->get();

        return view(
            'proyectoGrado.index',
            compact('proyectos', 'estudiantesDisponibles')
        );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Se mostrara las gestiones, cursos y profesores para mostrar en la vista
        $gestiones = Gestion::orderByDesc('id_gestion')->get();
        $cursos = Curso::orderBy('nombre')->get();
        $profesores = Profesor::orderBy('nombre')->get();

        return view(
            'proyectoGrado.create',
            compact(
                'gestiones',
                'cursos',
                'profesores'
            )
        );
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $idGestion = $request->input('idGestion', session('gestion_activa'));
        $idCurso = $request->input('idCurso');

        if (! $idCurso && $request->filled('idEstudiante')) {
            $idCurso = DB::table('inscripciones')
                ->where('id_estudiante', $request->idEstudiante)
                ->where('id_gestion', $idGestion)
                ->value('id_curso');
        }

        $tutoresDelModal = [
            '21' => ['Judith', 'Flores', 'Solar'],
            '67' => ['Roger', 'Cori', null],
            '66' => ['Jose Luis', 'Quisbert', 'Quisbert'],
            '1' => ['Javier Henry', 'Quispe', 'Pinto'],
        ];
        $tutorSeleccionado = $request->input('idProfesorTutor');

        if (isset($tutoresDelModal[$tutorSeleccionado])) {
            [$nombres, $appaterno, $apmaterno] = $tutoresDelModal[$tutorSeleccionado];
            $tutor = Profesor::where('nombres', 'like', "%{$nombres}%")
                ->where('appaterno', 'like', "%{$appaterno}%")
                ->when($apmaterno, fn ($query) => $query->where('apmaterno', 'like', "%{$apmaterno}%"))
                ->first();

            $tutorSeleccionado = $tutor?->id_profesor;
        }

        $estudiantesAdicionales = collect($request->input('idEstudiantes', []))
            ->filter(fn ($idEstudiante) => $idEstudiante && $idEstudiante !== 'none')
            ->values()
            ->all();

        $request->merge([
            'idCurso' => $idCurso,
            'idGestion' => $idGestion,
            'idProfesorTutor' => $tutorSeleccionado,
            'idEstudiantes' => $estudiantesAdicionales,
        ]);

        // Se enviaran los datos a ser registrado en la tabla
        $request->validate([
            'idEstudiante' => 'required|string|exists:estudiantes,id_estudiante',
            'idEstudiantes' => 'nullable|array',
            'idEstudiantes.*' => 'string|exists:estudiantes,id_estudiante',
            'idProfesorTutor' => 'required|integer|exists:profesores,id_profesor',
            'idCurso' => 'required|string|exists:cursos,id',
            'idGestion' => 'required|integer|exists:gestiones,id_gestion',
            'titulo' => 'required|max:300',
            'modalidad' => 'nullable|string|max:150',
            'descripcion' => 'nullable|string',
            'fechaInicio' => 'nullable|date',
            'fechaDefensa' => 'nullable|date',
            'observacion' => 'nullable|string',
        ]);

        DB::transaction(function () use ($request) {
            $proyecto = ProyectoGrado::create([
                'idEstudiante' => $request->idEstudiante,
                'idProfesorTutor' => $request->idProfesorTutor,
                'idCurso' => $request->idCurso,
                'idGestion' => $request->idGestion,
                'titulo' => $request->titulo,
                'lineaInvestigacion' => $request->modalidad,
                'descripcion' => $request->descripcion,
                'estado' => 'REGISTRADO',
                'fechaInicio' => $request->fechaInicio,
                'fechaDefensa' => $request->fechaDefensa,
                'observacion' => $request->observacion,
            ]);

            $estudiantes = collect($request->input('idEstudiantes', []))
                ->prepend($request->idEstudiante)
                ->unique()
                ->values();

            foreach ($estudiantes as $idEstudiante) {
                ProyectoEstudiante::create([
                    'idProyecto' => $proyecto->idProyecto,
                    'id_estudiante' => $idEstudiante,
                ]);
            }
        });

        return redirect()
            ->route('proyectoGrado.index')
            ->with('success', 'Proyecto registrado');

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        // Mostraremos el listado de todos los proyectos
        $proyecto = ProyectoGrado::with([
            'estudiante',
            'tutor',
            'curso',
            'gestion',
            'tribunales.profesor',
            'defensa',
        ])->findOrFail($id);

        return view(
            'proyectoGrado.show',
            compact('proyecto')
        );

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        // Se enviara los datos para la edicion de datos al proyecto de grado
        $proyecto = ProyectoGrado::findOrFail($id);
        $gestiones = Gestion::all();
        $cursos = Curso::all();
        $profesores = Profesor::all();

        return view(
            'proyectoGrado.edit',
            compact(
                'proyecto',
                'gestiones',
                'cursos',
                'profesores'
            )
        );
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        // Se enviaran los datos para la actualizacion de datos a la tabla
        $proyecto = ProyectoGrado::findOrFail($id);
        $proyecto->update([
            'idProfesorTutor' => $request->idProfesorTutor,
            'titulo' => $request->titulo,
            'lineaInvestigacion' => $request->lineaInvestigacion,
            'descripcion' => $request->descripcion,
            'estado' => $request->estado,
            'fechaInicio' => $request->fechaInicio,
            'fechaDefensa' => $request->fechaDefensa,
            'observacion' => $request->observacion,
        ]);

        return redirect()
            ->route('proyectoGrado.index')
            ->with('success', 'Proyecto actualizado');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        // Se realizara para la eliminacion de proyecto el id
        ProyectoGrado::findOrFail($id)->delete();

        return back()->with(
            'success',
            'Proyecto eliminado'
        );
    }

    public function pruebas()
    {
        /* $id = 'C26B';

         $estudiantes = Estudiante::with('proyectoGrado')
             ->whereHas('inscripciones', function ($query) use ($id) {
                 $query->where('id_curso', $id);
             })
             ->get();

          $estudiantes2 = DB::table('inscripciones')
             ->join(
                 'estudiantes',
                 'estudiantes.id_estudiante',
                 '=',
                 'inscripciones.id_estudiante'
             )
             ->leftJoin(
                 'proyectos_grado',
                 'proyectos_grado.idEstudiante',
                 '=',
                 'estudiantes.id_estudiante'
             )
             ->where('inscripciones.id_curso', 'C26A')
             ->select(
                 'estudiantes.id_estudiante',
                 'estudiantes.nombre',
                 'estudiantes.apellido',
                 'proyectos_grado.id_proyecto',
                 'proyectos_grado.nombre_proyecto'
             )
             ->get();
         $proyectos = Estudiante::with('proyectoGrado.tutor')
             ->whereHas('inscripciones', function ($query) use ($id) {
                 $query->where('id_curso', $id);
             })->orderBy('nombres', 'asc')
             ->get();
         dd($proyectos);

         dd([
             'idProyecto' => $estudiante->proyectoGrado->idProyecto,
             'idProfesorTutor' => $estudiante->proyectoGrado->idProfesorTutor,
         ]);*/
        $idProyecto = '5';
        $proyecto = ProyectoGrado::with([
            'estudiante',
            'proyectoEstudiantes.estudiante',
            'tutor',
            'curso',
            'gestion',
            'tribunales.profesor',
            'defensa',
            'seguimientos',
        ])->findOrFail($idProyecto);

        dd($proyecto);
    }

    public function login()
    {
        return view('proyectoGrado.login');
    }

    public function asignacion()
    {
        return view('proyectoGrado.asignacion');
    }

    public function distribucion()
    {
        return view('proyectoGrado.distribucion');
    }
}
