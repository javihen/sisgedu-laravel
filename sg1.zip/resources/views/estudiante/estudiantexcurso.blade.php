@extends('layouts.navhorizontal')

@section('content')
    <div class="ml-14 w-[calc(100%-80px)] absolute" style="font-family: 'poppins'">
        <div
            class="sticky top-0 z-1 ml-3 w-full mt-2 h-12 bg-[#3B82F6] rounded-md flex justify-between items-center pl-2 pr-2 ">
            <div>
                <a href="" id="openListadoEstudiantes"
                    class="py-1 px-2 rounded text-slate-700 border text-md border-slate-700 bg-white"><i
                        class="fa-regular fa-address-book"></i></a>
                <a href="{{ route('estudiante.reportePDF', $curso->id) }}" id="reportePDF"
                    class="py-1 px-2 rounded text-slate-700 border text-md border-slate-700 bg-white" target="_blank"><i
                        class="fa-regular fa-file-pdf"></i></a>
                <a href="" class="py-1 px-2 rounded text-green-700 border border-green-700 bg-white"><i
                        class="fa-regular fa-file-excel"></i></a>
            </div>
            {{-- <div class="bg-white w-fit px-4 text-center rounded-md">
                <p class="text-md italic uppercase">Comunicacion y Lenguajes: Lengua originaria</p>
                <p class="text-[10px]">Prof. Lourdes Mamani Chipana</p>

            </div> --}}
            <div class="bg-white w-72 text-center rounded-md">
                <p class="text-md ">{{ $curso->display_name }}</p>
                <p class="text-[10px]">Listado de estudiantes</p>
            </div>
        </div>
        @if (session('success'))
            <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 4000)" x-show="show" x-transition class="w-full ml-[18px] mr-4">
                <div
                    class="mt-2 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded shadow-md flex justify-between items-center">
                    <span>{{ session('success') }}</span>
                    <button @click="show = false"
                        class="ml-4 font-bold text-green-700 hover:text-green-900">&times;</button>
                </div>
            </div>
        @endif
        @if (session('error'))
            <div x-data="{ show: true }" x-init="setTimeout(() => show = true, 4000)" x-show="show" x-transition class="w-full ml-4 mr-4">
                <div
                    class="mt-2 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded shadow-md flex justify-between items-center">
                    <span>{{ session('error') }}</span>
                    <button @click="show = false" class="ml-4 font-bold text-red-700 hover:text-red-900">&times;</button>
                </div>
            </div>
        @endif

        <div class=" ml-3 w-full mt-2  flex flex-col gap-1 ">
            <div class="bg-white w-full  border border-slate-300 rounded-md">
                <table class="w-full ">
                    <tr class="bg-[#64748B] text-white text-sm text-center ">
                        <td class="py-2">Nro.</td>
                        <td>Codigo</td>
                        <td>Estudiante</td>
                        <td>Genero</td>
                        <td class="w-30">Estado</td>

                        <td>Opciones</td>
                    </tr>
                    @foreach ($estudiantes as $estudiante)
                        <tr class="text-sm text-center border-t border-slate-400 hover:bg-slate-200">
                            <td class="h-8">{{ $loop->iteration }}</td>
                            <td>{{ $estudiante->id_estudiante }}</td>
                            <td class="text-left">{{ $estudiante->appaterno }} {{ $estudiante->apmaterno }}
                                {{ $estudiante->nombres }}</td>

                            <td>
                                @if ($estudiante->genero == 'M')
                                    <p class="border border-blue-500 bg-white text-blue-500 rounded px-1 w-fit m-auto cursor-pointer genero-toggle"
                                        data-id="{{ $estudiante->id_estudiante }}">
                                        <i class="fa-solid fa-person"></i>
                                    </p>
                                @else
                                    <p class="border border-pink-500 bg-white text-pink-500 rounded px-1 w-fit m-auto cursor-pointer genero-toggle"
                                        data-id="{{ $estudiante->id_estudiante }}">
                                        <i class="fa-solid fa-person-dress"></i>
                                    </p>
                                @endif
                            </td>
                            <td>
                                @if ($estudiante->estado === 'E')
                                    <button type="button" data-id="{{ $estudiante->id_estudiante }}"
                                        class="estado-toggle px-2 py-1 my-2 text-xs text-green-500 border border-green-500 rounded w-fit hover:bg-green-500 hover:text-white cursor-pointer">
                                        Efectivo
                                    </button>
                                @elseif ($estudiante->estado === 'R')
                                    <button type="button" data-id="{{ $estudiante->id_estudiante }}"
                                        class="estado-toggle px-2 py-1 my-2 text-xs text-red-500 border border-red-500 rounded w-fit hover:bg-red-500 hover:text-white cursor-pointer">
                                        Retirado
                                    </button>
                                @elseif ($estudiante->estado === 'A')
                                    <button type="button" data-id="{{ $estudiante->id_estudiante }}"
                                        class="estado-toggle px-2 py-1 my-2 text-xs text-slate-500 border border-slate-500 rounded w-fit hover:bg-slate-500 hover:text-white cursor-pointer">
                                        Abandono
                                    </button>
                                @else
                                    <span class="px-2 text-sm text-gray-500"
                                        data-id="{{ $estudiante->id_estudiante }}">—</span>
                                @endif
                            </td>

                            <td>
                                <a href="#"
                                    class="btn-ver-boletin bg-[#1F1F1F] text-white px-2 py-2 rounded hover:text-[#1F1F1F] hover:bg-white border-2 border-[#1F1F1F]"
                                    data-id="{{ $estudiante->id_estudiante }}"><i class="fa-solid fa-book"></i>
                                    Calificaciones</a>
                                <a href="#"
                                    class="bg-[#888888] text-white text-xs px-2 py-2 rounded hover:text-[#888888] hover:bg-white border-2 border-[#888888] "><i
                                        class="fa-solid fa-list-check"></i> Asistencias</a>
                                <a href="#"
                                    class="bg-[#F62961] text-white text-xs px-2 py-2 rounded hover:text-[#F62961] hover:bg-white border-2 border-[#F62961] ">
                                    <i class="fa-solid fa-box"></i> Observaciones</a>
                                <form action="{{ route('estudiante.destroy', $estudiante->id_estudiante) }}" method="POST"
                                    class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" onclick="return confirm('¿Estás seguro de eliminar este curso?')"
                                        class="py-2 px-3 border border-red-500 bg-white my-2 rounded-sm text-red-500 hover:bg-red-500 hover:text-white cursor-pointer">
                                        <i class="fa-regular fa-trash-can"></i>
                                    </button>
                                </form>
                                {{-- <a href="#"
                                    class="ml-1 p-2 edit-btn border border-[#3B82F6] bg-white text-[#3B82F6] rounded-sm hover:bg-[#3B82F6] hover:text-white"
                                    data-id="{{ $estudiante->id_estudiante }}"
                                    data-codigo="{{ $estudiante->id_estudiante }}" data-estado="{{ $estudiante->estado }}"
                                    data-rude="{{ $estudiante->rude }}" data-ci="{{ $estudiante->ci }}"
                                    data-nombres="{{ $estudiante->nombres }}"
                                    data-appaterno="{{ $estudiante->appaterno }}"
                                    data-apmaterno="{{ $estudiante->apmaterno }}" data-genero="{{ $estudiante->genero }}"
                                    data-fecha="{{ $estudiante->fecha_nacimiento }}"
                                    data-observacion="{{ $estudiante->observacion }}"
                                    data-id_curso="{{ $estudiante->id_curso ?? 'SIN CURSO' }}">
                                    <i class='bx bx-edit-alt'></i> Editar
                                </a> --}}
                            </td>
                        </tr>
                    @endforeach

                </table>
            </div>

            <div id="boletinModal"
                class="hidden fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-900/70 p-4">
                <div
                    class="relative w-1/2 max-w-6xl rounded-3xl bg-white shadow-2xl ring-1 ring-slate-200 overflow-hidden py-2">
                    <div
                        class="flex flex-col gap-4 border-b border-slate-200 bg-white px-6 py-5 md:flex-row md:items-center md:justify-between">
                        <div>
                            <p class="text-xs uppercase tracking-[0.2em] text-slate-400">Boletín de calificaciones</p>
                            <h2 id="boletinTitulo" class="mt-2 text-2xl font-semibold text-slate-900">Estudiante</h2>
                            <p id="boletinSubtitulo" class="text-sm text-slate-500">Curso • Gestión</p>
                        </div>
                        <div class="flex flex-col gap-2 sm:flex-row sm:items-center">
                            <button id="btnImprimirBoletin" type="button"
                                class="inline-flex items-center justify-center rounded-full bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"><i
                                    class="fa-solid fa-print mr-2"></i>Imprimir</button>
                            <button id="closeBoletinModal" type="button"
                                class="inline-flex items-center justify-center rounded-full border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-400 hover:bg-slate-50">Cerrar</button>
                        </div>
                    </div>
                    <div class="print-area max-h-[76vh] overflow-hidden bg-slate-50">
                        <div class="overflow-x-auto">
                            <table class="min-w-full border-separate border-spacing-0 text-sm text-slate-700">
                                <thead
                                    class="sticky top-0 bg-slate-100 text-left text-xs uppercase tracking-wider text-slate-600">
                                    <tr>
                                        <th class="border-b border-slate-200 px-4 py-3">Área / Materia</th>
                                        <th class="border-b border-slate-200 px-4 py-3 text-center">1er Tri</th>
                                        <th class="border-b border-slate-200 px-4 py-3 text-center">2do Tri</th>
                                        <th class="border-b border-slate-200 px-4 py-3 text-center">3er Tri</th>
                                        <th class="border-b border-slate-200 px-4 py-3 text-center">P.Final</th>
                                    </tr>
                                </thead>
                                <tbody id="boletinBody" class="divide-y divide-slate-200 bg-white"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                #boletinModal.hidden {
                    display: none;
                }

                #boletinModal {
                    backdrop-filter: blur(6px);
                }

                .boletin-score-low {
                    color: #b91c1c;
                    font-weight: 600;
                }

                .boletin-final {
                    background-color: #2563eb;
                    color: white;
                }

                @media print {
                    body * {
                        visibility: hidden;
                    }

                    .print-area,
                    .print-area * {
                        visibility: visible;
                    }

                    #boletinModal {
                        position: static;
                        visibility: visible;
                    }

                    #boletinModal .print-area {
                        max-height: none;
                    }
                }
            </style>

            <div class="flex justify-end bg-white w-full  border border-slate-300 rounded-md mb-16 h-30">
                <div class="flex my-auto flex-col mr-2">
                    <a href=""
                        class="py-1 px-2 rounded mb-2 text-center text-slate-700 border text-md border-slate-700 bg-white"><i
                            class="fa-regular fa-address-book"></i> Adicionar estudiante</a>

                    <a href=""
                        class="py-1 px-2 rounded text-center text-green-700 border border-green-700 bg-white"><i
                            class="fa-regular fa-file-excel"></i> Generar archivo</a>
                </div>
            </div>
        </div>

        {{-- Nos crearemos el formulario modal con el que podamos nosotros registras a nuevos estudiantes --}}
        <div id="modal"
            class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm flex border-2 border-slate-600 items-center justify-center z-50">
            <!-- Contenedor del modal -->
            <div id="modalContent"
                class="bg-white rounded-md shadow-lg w-[622px] p-4 transform transition-all scale-95 opacity-0">

                <!-- Título -->
                <h2 class="text-md font-semibold mt-4 mb-6 text-left" id="modalTitle">REGISTRO DE NUEVO ESTUDIANTE</h2>
                <hr class="border border-slate-200 mb-4">
                <!-- Formulario -->
                <form class="space-y-4" id="formularioEstudiante" action="{{ route('estudiante.store') }}"
                    method="post">
                    @csrf
                    <input type="hidden" name="_method" id="formMethod" value="POST">

                    <div id="selectCursoCreate" class="basis-1/2 flex flex-col mt-2 w-full ">
                        <label for="id_curso" class="text-xs relative top-3 left-3 bg-white px-2 w-fit">Asignar a curso
                        </label>
                        <select name="id_curso" id="id_curso" class="border border-slate-600 bg-white p-2 rounded-md">
                            <option value="">- seleccione un curso -</option>
                        </select>
                    </div>
                    <div class="flex flex-row mt-4 gap-1">
                        <div class="basis-1/2 ">
                            <label for="codigo" class="text-xs relative top-3 left-3 bg-white px-2">Codigo </label>
                            <input type="text" name="codigo" id="codigo"
                                class="w-full border border-slate-700 rounded-md p-2 uppercase">
                        </div>
                        <div class="basis-1/2 flex flex-col mt-2 ">
                            <label for="rude" class="text-xs relative top-3 left-3 bg-white px-2 w-fit">Estado
                            </label>
                            <select name="estado" id="estado"
                                class="border border-slate-600 bg-white p-2 rounded-md">
                                <option value="E">EFECTIVO</option>
                                <option value="R">RETIRADO</option>
                                <option value="A">ABANDONO</option>
                            </select>
                        </div>
                    </div>
                    <div class="flex flex-row gap-1 mt-[-25px]">
                        <div class="basis-1/2 ">
                            <label for="rude" class="text-xs relative top-3 left-3 bg-white px-2">R.U.D.E. </label>
                            <input type="text" name="rude" id="rude"
                                class="w-full border border-slate-700 rounded-md p-2 uppercase">
                        </div>
                        <div class="basis-1/2">
                            <label for="rude" class="text-xs relative top-3 left-3 bg-white px-2">C.I. </label>
                            <input type="text" name="ci" id="ci"
                                class="w-full border border-slate-700 rounded-md p-2 uppercase">
                        </div>
                    </div>
                    <div class="mt-[-25px]">
                        <label for="rude" class="text-xs relative top-3 left-3 bg-white px-2">Nombre (s) </label>
                        <input type="text" name="nombres" id="nombres"
                            class="w-full border border-slate-700 rounded-md p-2 uppercase">
                    </div>
                    <div class="flex flex-row mt-[-25px] gap-1">
                        <div class="basis-1/2 ">
                            <label for="rude" class="text-xs relative top-3 left-3 bg-white px-2">Apellido paterno
                            </label>
                            <input type="text" name="appaterno" id="appaterno"
                                class="w-full border border-slate-700 rounded-md p-2 uppercase">
                        </div>
                        <div class="basis-1/2">
                            <label for="rude" class="text-xs relative top-3 left-3 bg-white px-2">Apellido materno
                            </label>
                            <input type="text" name="apmaterno" id="apmaterno"
                                class="w-full border border-slate-700 rounded-md p-2 uppercase">
                        </div>
                    </div>
                    <div class="flex flex-row mt-[-25px] gap-1">
                        <div class="basis-1/2 flex flex-col mt-2 ">
                            <label for="rude" class="text-xs relative top-3 left-3 bg-white px-2 w-fit">Genero
                            </label>
                            <select name="genero" id="genero"
                                class="border border-slate-600 bg-white p-2 rounded-md">
                                <option value="">seleccione</option>
                                <option value="M">MASCULINO</option>
                                <option value="F">FEMENINO</option>
                            </select>
                        </div>
                        <div class="basis-1/2">
                            <label for="rude" class="text-xs relative top-3 left-3 bg-white px-2">Fecha de nacimiento
                            </label>
                            <input type="date" name="fecha_nacimiento" id="fecha_nacimiento"
                                class="w-full border border-slate-700 rounded-md p-2 uppercase">
                        </div>
                    </div>
                    <div class="mt-[-25px]">
                        <label for="rude" class="text-xs relative top-3 left-3 bg-white px-2">Observaciones </label>
                        <textarea name="observacion" id="observacion" class="w-full border border-slate-700 rounded-md p-2 uppercase">
                        </textarea>
                    </div>
                    <hr class="border-slate-200 border">
                    <!-- Botones -->
                    <div class="flex justify-end space-x-2  ">
                        <button type="button" id="closeModal"
                            class="px-4 py-2 border border-gray-300 rounded-md w-1/2 hover:bg-gray-400 hover:text-white hover:cursor-pointer transition">Cancelar</button>
                        <button type="submit" id="submitBtn"
                            class="px-4 py-2 bg-blue-600 text-white w-1/2 rounded-lg hover:bg-blue-700 transition hover:cursor-pointer">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
        <div id="modalListado"
            class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
            data-curso-id="{{ $curso->id }}">
            <!-- Contenedor del modal -->
            <div id="modalListadoContent" class="bg-white rounded-md shadow-lg w-[800px] p-4 transform transition-all">

                <!-- Título -->
                <h2 class="text-md font-semibold mt-4 mb-6 text-left">LISTADO DE ESTUDIANTES</h2>
                <hr class="border border-slate-200 mb-4">

                <!-- Input de búsqueda -->
                <div class="mb-4">
                    <input type="text" id="inputBusqueda" placeholder="Buscar por nombre, RUDE o código..."
                        class="w-full border border-slate-300 rounded-md p-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Tabla de estudiantes -->
                <div class="overflow-auto max-h-96 border border-slate-300 rounded-md">
                    <table class="w-full">
                        <thead class="bg-[#64748B] text-white text-sm sticky top-0">
                            <tr>
                                <th class="py-2 px-2 text-center w-10">
                                    {{-- <input type="checkbox" id="checkboxSelectAll" class="cursor-pointer"> --}}
                                </th>
                                <th class="py-2 px-2 text-left">Codigo</th>
                                <th class="py-2 px-2 text-left">Rude</th>
                                <th class="py-2 px-2 text-left">Nombre Completo</th>
                                <th class="py-2 px-2 text-center">Genero</th>
                                <th class="py-2 px-2 text-center">Estado</th>
                            </tr>
                        </thead>
                        <tbody id="tablaEstudiantesBody">
                            <!-- Se llena dinamicamente con JavaScript -->
                        </tbody>
                    </table>
                </div>

                <hr class="border-slate-200 border mt-4">

                <!-- Botones -->
                <div class="flex justify-end space-x-2 mt-4">
                    <button type="button" id="closeModalListado"
                        class="px-4 py-2 border border-gray-300 rounded-md w-1/4 hover:bg-gray-400 hover:text-white hover:cursor-pointer transition">Cerrar</button>
                    <button type="button" id="btnSeleccionarEstudiantes"
                        class="px-4 py-2 bg-blue-600 text-white w-1/4 rounded-lg hover:bg-blue-700 transition hover:cursor-pointer">Registrarlos</button>
                </div>
            </div>
        </div>




    </div>

    <script>
        // Abrir modal de listado
        document.getElementById('openListadoEstudiantes').addEventListener('click', function(e) {
            e.preventDefault();
            const modal = document.getElementById('modalListado');
            modal.classList.remove('hidden');

            // Cargar los estudiantes
            cargarEstudiantes();
        });

        // Cerrar modal de listado
        document.getElementById('closeModalListado').addEventListener('click', function() {
            document.getElementById('modalListado').classList.add('hidden');
        });

        // Cargar estudiantes vía AJAX
        function cargarEstudiantes() {
            fetch('{{ route('estudiante.api.all') }}')
                .then(response => response.json())
                .then(data => {
                    // Guardar datos en una variable global para filtrado
                    window.estudiantes_data = data;

                    const tbody = document.getElementById('tablaEstudiantesBody');
                    tbody.innerHTML = ''; // Limpiar tabla

                    data.forEach((estudiante, index) => {
                        const row = document.createElement('tr');
                        row.className = 'border-t border-slate-400 hover:bg-slate-100';
                        row.addEventListener('click', function() {
                            toggleCheckbox(this);
                        });
                        row.setAttribute('data-codigo', estudiante.id_estudiante.toLowerCase());
                        row.setAttribute('data-rude', (estudiante.rude || '').toLowerCase());
                        row.setAttribute('data-nombre', (estudiante.appaterno + ' ' + estudiante.apmaterno +
                            ' ' + estudiante.nombres).toLowerCase());

                        const generoIcon = estudiante.genero === 'M' ?
                            '<i class="fa-solid fa-person"></i>' :
                            '<i class="fa-solid fa-person-dress"></i>';

                        const estadoClase = estudiante.estado === 'E' ? 'text-green-500' :
                            estudiante.estado === 'R' ? 'text-red-500' :
                            estudiante.estado === 'A' ? 'text-slate-500' : '';

                        const estadoTexto = estudiante.estado === 'E' ? 'Efectivo' :
                            estudiante.estado === 'R' ? 'Retirado' :
                            estudiante.estado === 'A' ? 'Abandono' : '';

                        row.innerHTML = `
                            <td class="py-2 px-2 text-center">
                                <input type="checkbox" class="checkbox-estudiante cursor-pointer" value="${estudiante.id_estudiante}">
                            </td>
                            <td class="py-2 px-2 text-sm">${estudiante.id_estudiante}</td>
                            <td class="py-2 px-2 text-sm">${estudiante.rude}</td>

                            <td class="py-2 px-2 text-sm" id='fila' onclick="toggleCheckbox(this)">${estudiante.appaterno} ${estudiante.apmaterno} ${estudiante.nombres}</td>
                            <td class="py-2 px-2 text-center text-sm">
                                <span class="border border-slate-400 rounded px-2 py-1 cursor-pointer genero-toggle-modal" data-id="${estudiante.id_estudiante}">
                                    ${generoIcon}
                                </span>
                            </td>
                            <td class="py-2 px-2 text-center text-sm">
                                <span class="border border-slate-400 rounded px-2 py-1 ${estadoClase}">
                                    ${estadoTexto}
                                </span>
                            </td>
                        `;

                        tbody.appendChild(row);
                    });

                    // Agregar listener al checkbox de seleccionar todos
                    /* document.getElementById('checkboxSelectAll').addEventListener('change', function() {
                        const checkboxes = document.querySelectorAll('.checkbox-estudiante');
                        checkboxes.forEach(checkbox => {
                            checkbox.checked = this.checked;
                        });
                    }); */

                    // Agregar evento de búsqueda
                    document.getElementById('inputBusqueda').addEventListener('keyup', filtrarEstudiantes);
                })
                .catch(error => {
                    console.error('Error cargando estudiantes:', error);
                    alert('Error al cargar los estudiantes');
                });
        }




        function toggleCheckbox(row) {
            const checkbox = row.querySelector('input[type="checkbox"]');

            if (!checkbox) {
                console.error('Checkbox no encontrado en la fila', row);
                return;
            }

            checkbox.checked = !checkbox.checked;
        }


        document.addEventListener('onclick', function(e) {
            if (e.target && e.target.id == 'fila') {
                console.log('hola');
            }
        });
        // Función para filtrar estudiantes en tiempo real
        function filtrarEstudiantes() {
            const busqueda = document.getElementById('inputBusqueda').value.toLowerCase();
            const filas = document.querySelectorAll('#tablaEstudiantesBody tr');

            filas.forEach(fila => {
                const codigo = fila.getAttribute('data-codigo');
                const rude = fila.getAttribute('data-rude');
                const nombre = fila.getAttribute('data-nombre');

                // Mostrar fila si coincide con el código, rude o nombre
                if (codigo.includes(busqueda) || rude.includes(busqueda) || nombre.includes(busqueda)) {
                    fila.style.display = '';
                } else {
                    fila.style.display = 'none';
                }
            });
        }

        // Manejar selección de estudiantes
        document.getElementById('btnSeleccionarEstudiantes').addEventListener('click', function() {
            const checkboxes = document.querySelectorAll('.checkbox-estudiante:checked');
            const seleccionados = Array.from(checkboxes).map(cb => cb.value);

            if (seleccionados.length === 0) {
                alert('Por favor selecciona al menos un estudiante');
                return;
            }

            // Obtener el ID del curso desde el atributo data del modal
            const idCurso = document.getElementById('modalListado').getAttribute('data-curso-id');

            // Enviar los datos al servidor
            fetch('{{ route('inscripcion.inscribir-multiples') }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        estudiante_ids: seleccionados,
                        id_curso: idCurso
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        if (data.errores && data.errores.length > 0) {
                            console.warn('Errores:', data.errores);
                        }
                        document.getElementById('modalListado').classList.add('hidden');
                        // Recargar la página para ver los cambios
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al procesar la inscripción');
                });
        });

        // Cambiar género en tabla principal
        document.addEventListener('click', function(e) {
            if (e.target.closest('.genero-toggle')) {
                const elemento = e.target.closest('.genero-toggle');
                const id = elemento.getAttribute('data-id');
                cambiarGeneroEstudiante(id, elemento);
            }
        });

        // Cambiar género en modal de listado
        document.addEventListener('click', function(e) {
            if (e.target.closest('.genero-toggle-modal')) {
                const elemento = e.target.closest('.genero-toggle-modal');
                const id = elemento.getAttribute('data-id');
                cambiarGeneroEstudiante(id, elemento);
            }
        });

        // Función para cambiar el género
        function cambiarGeneroEstudiante(id, elemento) {
            fetch('{{ route('estudiante.cambiarGenero', ['id' => 'PLACEHOLDER']) }}'.replace('PLACEHOLDER', id), {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Actualizar el icono y colores dinámicamente
                        if (data.genero === 'M') {
                            elemento.innerHTML = '<i class="fa-solid fa-person"></i>';
                            elemento.className =
                                'border border-blue-500 bg-white text-blue-500 rounded px-1 w-fit m-auto cursor-pointer genero-toggle';
                            elemento.setAttribute('data-id', id);
                        } else {
                            elemento.innerHTML = '<i class="fa-solid fa-person-dress"></i>';
                            elemento.className =
                                'border border-pink-500 bg-white text-pink-500 rounded px-1 w-fit m-auto cursor-pointer genero-toggle';
                            elemento.setAttribute('data-id', id);
                        }
                        console.log('Género actualizado correctamente');
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al actualizar el género');
                });
        }

        const boletinRutaTemplate = '{{ route('boletin.obtener', ['idEstudiante' => ':id']) }}';

        document.addEventListener('click', function(event) {
            const button = event.target.closest('.btn-ver-boletin');
            if (!button) {
                return;
            }

            event.preventDefault();
            const idEstudiante = button.getAttribute('data-id');
            abrirBoletin(idEstudiante);
        });

        document.getElementById('closeBoletinModal').addEventListener('click', function() {
            document.getElementById('boletinModal').classList.add('hidden');
        });

        document.getElementById('btnImprimirBoletin').addEventListener('click', function() {
            window.print();
        });

        function formatNota(value) {
            return value === null || value === undefined ? '-' : value;
        }

        function abrirBoletin(idEstudiante) {
            const modal = document.getElementById('boletinModal');
            const body = document.getElementById('boletinBody');
            const titulo = document.getElementById('boletinTitulo');
            const subtitulo = document.getElementById('boletinSubtitulo');

            body.innerHTML =
                '<tr><td colspan="5" class="px-4 py-8 text-center text-slate-500">Cargando boletín...</td></tr>';
            modal.classList.remove('hidden');

            const url = boletinRutaTemplate.replace(':id', encodeURIComponent(idEstudiante));

            fetch(url, {
                    headers: {
                        'Accept': 'application/json',
                    },
                })
                .then(response => {
                    if (!response.ok) {
                        return response.json().then(err => {
                            throw new Error(err.error || 'Error al cargar el boletín.');
                        });
                    }

                    return response.json();
                })
                .then(data => {
                    const estudiante = data.estudiante || {};
                    titulo.textContent = estudiante.nombre_completo || 'Estudiante';
                    subtitulo.textContent =
                        `${estudiante.curso || 'Sin curso'} • ${estudiante.gestion || 'Sin gestión'}`;

                    if (!data.asignaciones || data.asignaciones.length === 0) {
                        body.innerHTML =
                            '<tr><td colspan="5" class="px-4 py-8 text-center text-slate-500">Este estudiante no tiene calificaciones registradas.</td></tr>';
                        return;
                    }

                    body.innerHTML = data.asignaciones.map(asignacion => {
                        const nota1 = formatNota(asignacion.notas['1']);
                        const nota2 = formatNota(asignacion.notas['2']);
                        const nota3 = formatNota(asignacion.notas['3']);
                        const promedio = formatNota(asignacion.promedio_final);

                        const nota1Class = asignacion.notas['1'] !== null && asignacion.notas['1'] < 51 ?
                            'boletin-score-low' : '';
                        const nota2Class = asignacion.notas['2'] !== null && asignacion.notas['2'] < 51 ?
                            'boletin-score-low' : '';
                        const nota3Class = asignacion.notas['3'] !== null && asignacion.notas['3'] < 51 ?
                            'boletin-score-low' : '';

                        return `
                            <tr class="border-b border-slate-200 hover:bg-slate-200 odd:bg-white even:bg-slate-50">
                                <td class="px-4 py-1 align-top w-fit">
                                    <div class="text-sm font-medium text-slate-900">${asignacion.materia}</div>
                                    <div class="mt-1 text-[10px] text-slate-500">PROF. ${asignacion.profesor}</div>
                                </td>
                                <td class="px-4 py-1 text-center ${nota1Class}">${nota1}</td>
                                <td class="px-4 py-1 text-center ${nota2Class}">${nota2}</td>
                                <td class="px-4 py-1 text-center ${nota3Class}">${nota3}</td>
                                <td class="px-4 py-1 text-center">
                                    <span class="inline-flex min-w-[56px] items-center justify-center rounded-full px-3 py-1 text-sm font-semibold boletin-final">${promedio}</span>
                                </td>
                            </tr>`;
                    }).join('');
                })
                .catch(error => {
                    console.error('Error cargando boletín:', error);
                    body.innerHTML =
                        '<tr><td colspan="5" class="px-4 py-8 text-center text-red-600">No se pudo cargar el boletín. Intente de nuevo.</td></tr>';
                });
        }

        // --- INICIO: Lógica para cambiar estado del estudiante ---
        document.addEventListener('click', function(e) {
            // Verificar si el clic fue en un botón de cambio de estado
            if (e.target.matches('.estado-toggle')) {
                e.preventDefault();
                const button = e.target;
                const studentId = button.dataset.id;
                cambiarEstadoEstudiante(studentId, button);
            }
        });

        function cambiarEstadoEstudiante(studentId, button) {
            // Construir la URL para la petición
            const url = `{{ route('estudiante.cambiarEstado', ['id' => ':id']) }}`.replace(':id', studentId);

            // Realizar la petición fetch
            fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Actualizar el botón en la UI sin recargar la página
                        actualizarBotonEstado(button, data.estado);
                    } else {
                        // Mostrar un error si algo falla
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Ocurrió un error de red al intentar cambiar el estado.');
                });
        }

        function actualizarBotonEstado(button, nuevoEstado) {
            // Definir los estilos y textos para cada estado
            const estados = {
                'E': {
                    texto: 'Efectivo',
                    clase: 'text-green-500 border-green-500 hover:bg-green-500'
                },
                'R': {
                    texto: 'Retirado',
                    clase: 'text-red-500 border-red-500 hover:bg-red-500'
                },
                'A': {
                    texto: 'Abandono',
                    clase: 'text-slate-500 border-slate-500 hover:bg-slate-500'
                }
            };

            const config = estados[nuevoEstado];

            if (config) {
                // Actualizar el texto del botón
                button.textContent = config.texto;
                // Resetear y aplicar las nuevas clases de estilo
                button.className =
                    `estado-toggle px-2 py-1 my-2 text-xs border rounded w-fit hover:text-white cursor-pointer ${config.clase}`;
            }
        }
        // --- FIN: Lógica para cambiar estado del estudiante ---
    </script>
@endsection
