<?php

namespace App\Http\Controllers;

use App\Models\Profesor;
use App\Models\Usuario;
use App\Models\Asignacion;
use App\Models\AsesoresCursos;
use App\Models\Curso;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;

class ProfesorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $gestionId = session('gestion_activa');

        $profesores = Profesor::with(['asesoresCursos' => function ($query) use ($gestionId) {
            $query->where('id_gestion', $gestionId)
                ->with('curso');
        }])->orderBy('appaterno','asc')->get();

        $cursos = Curso::orderBy('nivel')
            ->orderBy('grado')
            ->orderBy('paralelo')
            ->get();

        return view('profesor.index', compact('profesores', 'cursos'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {

        $request->validate([
            'ci' => 'required',
            'rda' => 'required',
            'nombres' => 'required|string|max:255',
            'genero' => 'required|in:M,F',
            'nivelFormacion' => 'required|string|max:255',
        ]);
            $toUpper = fn($v) => $v === null ? null : mb_strtoupper(trim($v), 'UTF-8');

        Profesor::create([
            'ci' => $request->ci,
            'rda' => $request->rda,
            'nombres' =>$toUpper($request->nombres),
            'appaterno' => $toUpper($request->appaterno),
            'apmaterno' => $toUpper($request->apmaterno),
            'genero' => $request->genero,
            'estado'=>'I',
            'fechaNac' => $request->fechaNac,
            'fuenteFinan' => $request->fuenteFinan,
            'nivelFormacion' => $toUpper($request->nivelFormacion),
            'observacion' => $toUpper($request->observacion),
        ]);
        session()->flash('swal', [
            'icon' => 'success',
            'title' => 'Bien hecho!',
            'text' => 'Profesor creado exitosamente.'
        ]);
        return redirect()->route('profesor.index')->with('success', 'Profesor creado exitosamente.');

        } catch (\Exception $e) {
            session()->flash('swal', [
            'icon' => 'error',
            'title' => 'Que mal!',
            'text' => 'Error al crear el profesor.'
        ]);
            return redirect()->route('profesor.index')->with('error', 'Error al crear el profesor: ' . $e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Profesor $profesor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Profesor $profesor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try{
            $profesor = Profesor::where('id_profesor', $id)->first();
            if (!$profesor) {
                return redirect()->route('profesor.index')->with('error', 'Profesor no encontrado.');
            }

            $profesor->update([
                'ci' => $request->ci,
                'rda' => $request->rda,
                'nombres' => mb_strtoupper(trim($request->nombres), 'UTF-8'),
                'appaterno' => mb_strtoupper(trim($request->appaterno), 'UTF-8'),
                'apmaterno' => mb_strtoupper(trim($request->apmaterno), 'UTF-8'),
                'genero' => $request->genero,
                'fechaNac' => $request->fechaNac,
                'fuenteFinan' => $request->fuenteFinan,
                'nivelFormacion' => mb_strtoupper(trim($request->nivelFormacion), 'UTF-8'),
                'observacion' => mb_strtoupper(trim($request->observacion), 'UTF-8'),
            ]);
            session()->flash('swal', [
            'icon' => 'success',
            'title' => 'Genial!!',
            'text' => 'Profesor actualizado exitosamente.'
        ]);
            return redirect()->route('profesor.index')->with('success', 'Profesor actualizado exitosamente
.');
        } catch (\Exception $e) {
            session()->flash('swal', [
            'icon' => 'error',
            'title' => 'Que mal!',
            'text' => 'Error al actualizar el profesor.'
        ]);
            return redirect()->route('profesor.index')->with('error', 'Error al actualizar el
    profesor: ' . $e->getMessage());

        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($profesor)
    {
        try{
            $prof = Profesor::findOrFail($profesor);
            $prof->delete();
            session()->flash('swal', [
            'icon' => 'success',
            'title' => 'Genial!!',
            'text' => 'Profesor eliminado exitosamente.'
        ]);
            return redirect()->route('profesor.index')->with('success', 'Profesor eliminado exitosamente.');
        } catch (\Exception $e) {
            session()->flash('swal', [
            'icon' => 'error',
            'title' => 'Que mal!',
            'text' => 'Error al borrar el profesor.'
        ]);
            return redirect()->route('profesor.index')->with('error', 'Error al eliminar el profesor: ' . $e->getMessage());
        }
    }

    public function perfil($id)
    {
        $profesor = Profesor::findOrFail($id);
        //En la consulta nos falta realizar la ordenacion por turno, nivel, grado y paralelo

        $asignaciones = Asignacion::select('asignaciones.*')
            ->join('cursos', 'cursos.id', '=', 'asignaciones.idcurso')
            ->join('materias', 'materias.id_materia', '=', 'asignaciones.id_materia') // opcional
            ->where('asignaciones.id_profesor', $id)
            ->where('id_gestion', session('gestion_activa'))
            ->orderBy('cursos.nivel', 'asc')
            ->orderBy('cursos.turno', 'asc')
            ->orderBy('cursos.paralelo', 'asc')
            ->with(['curso', 'materia']) // si quieres los modelos relacionados además
            ->get();

        //    return $asignaciones;

        return view('profesor.perfil', compact('profesor', 'asignaciones'));
    }

    public function cambiarEstado($id)
    {
        $profesor = Profesor::findOrFail($id);

        // Si está ACTIVO → pasará a INACTIVO → SE CREA usuario
        if ($profesor->estado === 'I') {

            $profesor->estado = 'A';
            $profesor->save();

            // Registrar en tabla usuarios
            Usuario::create([
                'username' => $profesor->nombres,
                'email' => 'nombre@mail.com',
                'password' => Hash::make($profesor->ci),
                'estado' => 1,
                'idRol' => 2, // si deseas rol profesor
                'id_profesor'=>$profesor->id_profesor
            ]);
        } else {
            // Si está INACTIVO → pasará a ACTIVO → ELIMINAR usuario
            $profesor->estado = 'I';
            $profesor->save();

            Usuario::where('id_profesor', $profesor->id_profesor)->delete();
        }

        return back()->with('success', 'Estado actualizado correctamente.');
    }

    public function guardarAsesorCurso(Request $request, $id)
    {
        $request->validate([
            'curso_id' => 'required|exists:cursos,id',
        ]);

        $gestionId = session('gestion_activa');

        if (!$gestionId) {
            return back()->with('error', 'No hay una gestión activa seleccionada.');
        }

        $profesor = Profesor::findOrFail($id);

        $asesoria = AsesoresCursos::where('id_profesor', $profesor->id_profesor)
            ->where('id_gestion', $gestionId)
            ->first();

        if ($asesoria) {
            $asesoria->update([
                'id' => $request->curso_id,
                'estado' => $asesoria->estado ?? 'A',
                'observaciones' => $asesoria->observaciones ?? '',
            ]);
        } else {
            AsesoresCursos::create([
                'estado' => 'A',
                'observaciones' => '',
                'id_profesor' => $profesor->id_profesor,
                'id' => $request->curso_id,
                'id_gestion' => $gestionId,
            ]);
        }

        return back()->with('success', 'Asignación de asesoría registrada correctamente.');
    }

    /**
     * Import professors from file
     */
    public function import(Request $request)
    {
        // Validar que se recibió el campo excelData
        if (!$request->has('excelData') || empty($request->excelData)) {
            return back()->with('error', 'No se encontraron datos para importar.');
        }

        $data = json_decode($request->excelData, true);

        // Verificar que json_decode fue exitoso y que es un array
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data) || empty($data)) {
            return back()->with('error', 'Los datos del archivo no son válidos. Verifique el formato del archivo Excel.');
        }

        // Verificar que tenga al menos una fila (encabezados)
        if (count($data) < 2) {
            return back()->with('error', 'El archivo debe contener al menos los encabezados y una fila de datos.');
        }

        // Primera fila es encabezado
        $headers = $data[0];
        unset($data[0]); // quitar encabezados

        $importedCount = 0;

        foreach ($data as $row) {
            // Verificar que la fila sea un array válido
            if (!is_array($row)) {
                continue; // saltar filas inválidas
            }

            // Verificar que tenga al menos las columnas mínimas requeridas
            if (count($row) < 5) {
                continue; // evitar filas con muy pocos datos
            }

            // Verificar que al menos tenga CI y nombres (datos esenciales)
            if (empty($row[1]) || empty($row[4])) {
                continue; // saltar filas sin CI o nombres
            }

            try {
                Profesor::create([
                    'rda' => $row[0] ?? null,
                    'ci' => $row[1] ?? null,
                    'appaterno' => $row[2] ?? null,
                    'apmaterno' => $row[3] ?? null,
                    'nombres' => $row[4] ?? null,
                    'genero' => $row[5] ?? null,
                    'fechaNac' => $this->convertirFecha($row[6] ?? null),
                    'nivelFormacion' => $row[7] ?? null,
                    'fuenteFinan' => $row[8] ?? null,
                    'observacion' => $row[9] ?? null,
                    'estado' => 'I',
                ]);
                $importedCount++;
            } catch (\Exception $e) {
                // Log del error pero continuar con las demás filas
                \Log::error('Error importando profesor: ' . $e->getMessage(), ['row' => $row]);
                continue;
            }
        }

        if ($importedCount > 0) {
            return redirect()->route('profesor.index')->with('success', "Se importaron {$importedCount} profesores correctamente.");
        } else {
            return back()->with('error', 'No se pudo importar ningún profesor. Verifique que los datos sean correctos.');
        }
    }

    private function convertirFecha($fecha)
    {
        if (!$fecha) return null;

        // Si es un número serial de Excel
        if (is_numeric($fecha)) {
            return \Carbon\Carbon::createFromTimestamp(($fecha - 25569) * 86400)->format('Y-m-d');
        }

        // Intentar parsear como fecha
        try {
            return \Carbon\Carbon::parse($fecha)->format('Y-m-d');
        } catch (\Exception $e) {
            return null;
        }
    }
}
