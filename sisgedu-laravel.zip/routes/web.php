<?php

use App\Http\Controllers\AsignacionController;
use App\Http\Controllers\AsistenciaController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CitacionController;
use App\Http\Controllers\CitacionV2Controller;
use App\Http\Controllers\CursoController;
use App\Http\Controllers\EntrevistaController;
use App\Http\Controllers\EstudianteController;
use App\Http\Controllers\GestionController;
use App\Http\Controllers\MateriaController;
use App\Http\Controllers\NotaController;
use App\Http\Controllers\PermisoController;
use App\Http\Controllers\ProfesorController;
use App\Http\Controllers\PromedioFinalController;
use App\Http\Controllers\RolController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// ------------------------- MODULO LOGIN ------------------------//
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

// ------------------------- MODULO GESTION --------------------------//
Route::get('/panel', function () {
    return view('panel');
});
Route::get('/panel', [GestionController::class, 'index'])->name('panel');
Route::post('/gestion/store', [GestionController::class, 'store'])->name('gestion.store');
Route::post('/gestion/cambiar-estado/{id}', [GestionController::class, 'cambiarEstado'])->name('gestion.cambiarEstado');

// -------------- MODULO CURSO ---------------------//
Route::get('/curso', [CursoController::class, 'index'])->name('curso.index');
Route::post('/curso/store', [CursoController::class, 'store'])->name('curso.store');
Route::delete('/curso/destroy/{id}', [CursoController::class, 'destroy'])->name('curso.destroy');
Route::get('/curso/asignado/{id}', [CursoController::class, 'CursosAsignados'])->name('curso.asignados');
Route::get('/curso/{turno}/{nivel}', [CursoController::class, 'getCursos'])->name('curso.getCursos');
// API: todos los cursos (para poblar selects)
Route::get('/cursos', [CursoController::class, 'listAll'])->name('curso.listAll');
Route::get('/cursos/nivel/{nivel}', [CursoController::class, 'getCursosNivel'])->name('curso.getCursosNivel');

// -------------- MODULO ESTUDIANTE --------------------//

Route::get('/estudiante', [EstudianteController::class, 'index'])->name('estudiante.index');
Route::post('/estudiante/store', [EstudianteController::class, 'store'])->name('estudiante.store');
Route::post('/estudiante/import', [EstudianteController::class, 'import'])->name('estudiante.import');
Route::delete('/estudiante/destroy/{id}', [EstudianteController::class, 'destroy'])->name('estudiante.destroy');
Route::put('/estudiante/{id}', [EstudianteController::class, 'update'])->name('estudiante.update');
Route::get('/estudiante-curso/{id}', [EstudianteController::class, 'estudiantexcurso'])->name('estudiante.curso');
Route::get('/boletin/{idEstudiante}/json', [\App\Http\Controllers\BoletinController::class, 'obtenerBoletin'])->name('boletin.obtener');

Route::get('/estudiante-asistencia/{id}', [EstudianteController::class, 'estudiantexasistencia'])->name('estudiante.asistencia');

Route::get('/estudiante-curso/{id}/reporte', [EstudianteController::class, 'reportePDF'])->name('estudiante.reportePDF');
Route::get('/api/estudiantes/all', [EstudianteController::class, 'getAllEstudiantes'])->name('estudiante.api.all');
Route::post('/inscripcion/inscribir-multiples', [EstudianteController::class, 'inscribirMultiples'])->name('inscripcion.inscribir-multiples');
Route::post('/estudiante/cambiar-genero/{id}', [EstudianteController::class, 'cambiarGenero'])->name('estudiante.cambiarGenero');

// --------------- MODULO MATERIA ----------------------//
Route::get('/materia', [MateriaController::class, 'index'])->name('materia.index');
Route::post('/materia/store', [MateriaController::class, 'store'])->name('materia.store');
Route::delete('/materia/destroy/{id}', [MateriaController::class, 'destroy'])->name('materia.destroy');
Route::get('/materia/nivel/{nivel}', [MateriaController::class, 'getMateriasByNivel'])->name('materia.getMateriasByNivel');
Route::get('/materia/asignacion', [MateriaController::class, 'asignacion1'])->name('materia.asignacion');
Route::get('materia/cargaHoraria', [MateriaController::class, 'cargaHoraria'])->name('materia.cargaHoraria');

// ----------------- MODULO PROFESOR ------------------------//
Route::get('/profesor', [ProfesorController::class, 'index'])->name('profesor.index');
Route::post('/profesor/store', [ProfesorController::class, 'store'])->name('profesor.store');
Route::delete('/profesor/destroy/{id}', [ProfesorController::class, 'destroy'])->name('profesor.destroy');
Route::get('/profesor/perfil/{id}', [ProfesorController::class, 'perfil'])->name('profesor.perfil');
Route::put('/profesor/{id}', [ProfesorController::class, 'update'])->name('profesor.update');
Route::post('/profesor/cambiar-estado/{id}', [ProfesorController::class, 'cambiarEstado'])->name('profesor.cambiarEstado');
Route::post('/profesor/{id}/asesor-curso', [ProfesorController::class, 'guardarAsesorCurso'])->name('profesor.asesor-curso.store');
Route::post('/profesor/import', [ProfesorController::class, 'import'])->name('profesor.import');

// -------------------- MODULO ASIGNACION --------------------//
Route::post('/asignacion/store', [AsignacionController::class, 'store'])->name('asignacion.store');
Route::delete('/asignacion/destroy/{id}', [AsignacionController::class, 'destroy'])->name('asignacion.destroy');
Route::get('/asignacion/curso', [AsignacionController::class, 'asignacionxcurso'])->name('asignacion.curso');
Route::get('/api/asignacion/curso', [AsignacionController::class, 'getAsignacionesCurso'])->name('asignacion.getAsignacionesCurso');
Route::post('/curso-materia/store', [AsignacionController::class, 'storeCursoMateria'])->name('curso-materia.store');
Route::delete('/curso-materia/{id}', [AsignacionController::class, 'destroyCursoMateria'])->name('curso-materia.destroy');
// -------------------- MODULO ASISTENCIA --------------------//
Route::post('/asistencia/store', [AsistenciaController::class, 'store'])->name('asistencia.store');
Route::get('/api/inscritos-curso/{idCurso}', [AsistenciaController::class, 'obtenerInscritosPorCurso'])->name('asistencia.inscritos');

// ----------------------- MODULO ADMINISTRACIÓN: ROLES Y PERMISOS -----------------------//
// ROLES - Solo administradores
Route::get('/admin/roles', [RolController::class, 'index'])->name('roles.index')->middleware('permiso:gestionar_roles');
Route::get('/admin/roles/create', [RolController::class, 'create'])->name('roles.create')->middleware('permiso:gestionar_roles');
Route::post('/admin/roles', [RolController::class, 'store'])->name('roles.store')->middleware('permiso:gestionar_roles');
Route::get('/admin/roles/{id}/edit', [RolController::class, 'edit'])->name('roles.edit')->middleware('permiso:gestionar_roles');
Route::put('/admin/roles/{id}', [RolController::class, 'update'])->name('roles.update')->middleware('permiso:gestionar_roles');
Route::delete('/admin/roles/{id}', [RolController::class, 'destroy'])->name('roles.destroy')->middleware('permiso:gestionar_roles');

// PERMISOS - Solo administradores
Route::get('/admin/permisos', [PermisoController::class, 'index'])->name('permisos.index')->middleware('permiso:gestionar_roles');
Route::get('/admin/permisos/create', [PermisoController::class, 'create'])->name('permisos.create')->middleware('permiso:gestionar_roles');
Route::post('/admin/permisos', [PermisoController::class, 'store'])->name('permisos.store')->middleware('permiso:gestionar_roles');
Route::get('/admin/permisos/{id}/edit', [PermisoController::class, 'edit'])->name('permisos.edit')->middleware('permiso:gestionar_roles');
Route::put('/admin/permisos/{id}', [PermisoController::class, 'update'])->name('permisos.update')->middleware('permiso:gestionar_roles');
Route::delete('/admin/permisos/{id}', [PermisoController::class, 'destroy'])->name('permisos.destroy')->middleware('permiso:gestionar_roles');

// ----------------------- MODULO CITACIONES -----------------------//
Route::get('/citacion', [CitacionController::class, 'index'])->name('citacion.index');
Route::get('/citacion/import', [CitacionController::class, 'showImportForm'])->name('citacion.import');
Route::post('/citacion/import', [CitacionController::class, 'import'])->name('citacion.import');
Route::post('/citacion/store', [CitacionController::class, 'store'])->name('citacion.store');
Route::get('/citacion/{citacion}/edit', [CitacionController::class, 'edit'])->name('citacion.edit');
Route::put('/citacion/{citacion}', [CitacionController::class, 'update'])->name('citacion.update');
Route::delete('/citacion/{citacion}', [CitacionController::class, 'destroy'])->name('citacion.destroy');
// PDF Routes
Route::get('/citacion/pdf/curso/{idCurso}', [CitacionController::class, 'generarPDFCurso'])->name('citacion.pdf.curso');
Route::get('/citacion/pdf/general', [CitacionController::class, 'generarPDFGeneral'])->name('citacion.pdf.general');
Route::get('/citacion/pdf/estudiante/{idEstudiante}', [CitacionController::class, 'generarPDFEstudiante'])->name('citacion.pdf.estudiante');
Route::get('/citacion/panel-control', [CitacionV2Controller::class, 'index2'])->name('citacion.panel-control');
// ----------------------- MODULO CITACIONES V2 -----------------------//
Route::get('/citacionv2', [CitacionV2Controller::class, 'index'])->name('citacionv2.index');
// Cambio: la ruta del modal ahora usa la asignación concreta del profesor para abrir una sesión distinta por materia.
Route::get('/citacion/asignacion/{idAsignacion}/estudiantes', [CitacionV2Controller::class, 'estudiantesPorAsignacion'])->name('citacion.asignacion.estudiantes');
Route::get('/citacion/curso/{id}/estudiantes', [CitacionV2Controller::class, 'estudiantesPorCurso'])->name('citacion.curso.estudiantes');
Route::post('/citacion/registrar', [CitacionV2Controller::class, 'registrar'])->name('citacion.registrar');
Route::post('/citacion/toggle-registro', [CitacionV2Controller::class, 'toggleRegistro'])->name('citacion.toggle-registro');
Route::post('/citacion/cerrar-sesion', [CitacionV2Controller::class, 'cerrarSesion'])->name('citacion.cerrar-sesion');
Route::get('/citacion/imprimir-listado/{idAsignacion}', [CitacionV2Controller::class, 'imprimirListado'])->name('citacion.imprimir-listado');

// ----------------------- MODULO ENTREVISTAS -----------------------//
Route::get('/entrevistas', [EntrevistaController::class, 'index'])->name('entrevistas.index');
Route::get('/entrevistas/create', [EntrevistaController::class, 'create'])->name('entrevistas.create');
Route::post('/entrevistas', [EntrevistaController::class, 'store'])->name('entrevistas.store');
Route::get('/entrevistas/{entrevista}', [EntrevistaController::class, 'show'])->name('entrevistas.show');
Route::get('/entrevistas/{entrevista}/edit', [EntrevistaController::class, 'edit'])->name('entrevistas.edit');
Route::put('/entrevistas/{entrevista}', [EntrevistaController::class, 'update'])->name('entrevistas.update');
Route::delete('/entrevistas/{entrevista}', [EntrevistaController::class, 'destroy'])->name('entrevistas.destroy');

// ----------------------- MODULO NOTAS -----------------------//
Route::get('/notas', [NotaController::class, 'index'])->name('notas.index');
Route::get('/notas/import', [NotaController::class, 'importForm'])->name('notas.import-form');
Route::post('/notas/import', [NotaController::class, 'import'])->name('notas.import');
Route::get('/notas/descargar-plantilla', [NotaController::class, 'descargarPlantilla'])->name('notas.descargar-plantilla');
Route::post('/notas/upload-file', [NotaController::class, 'uploadFile'])->name('notas.upload-file');
Route::post('/notas/preview-sheet', [NotaController::class, 'previewSheet'])->name('notas.preview-sheet');
Route::get('/notas/centralizador/{idCurso}', [NotaController::class, 'showCentralizador'])->name('notas.centralizador');
Route::post('/notas/delete-by-periodo', [NotaController::class, 'deleteByPeriodo'])->name('notas.delete-by-periodo');
Route::get('/promedios-finales', [PromedioFinalController::class, 'index'])->name('promedios.finales');
Route::post('/notas/import-data', [NotaController::class, 'importData'])->name('notas.import-data');

/* ---------------  RUTAS PARA CONSULTAS DE PRUEBA ---------------------- */
Route::get('/citaciones/cantidad', [CitacionV2Controller::class, 'contarCitaciones']);

Route::get('/citaciones/prueba', [CitacionV2Controller::class, 'prueba']);
